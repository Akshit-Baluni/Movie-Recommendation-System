import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import pickle
import pandas as pd
import requests
import io
import ast
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load model data
movies = pd.read_csv("tmdb_5000_movies.csv")
credits = pd.read_csv("tmdb_5000_credits.csv")
movies_data = movies.merge(credits, on='title')

# Extract genres
def extract_genre_list(genre_str):
    try:
        return [g['name'] for g in ast.literal_eval(genre_str)]
    except:
        return []

# Add genre list to merged dataset
movies_data['genre_list'] = movies_data['genres'].apply(extract_genre_list)

# Calculate TF-IDF matrix for plot summaries
tfidf_vectorizer = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf_vectorizer.fit_transform(movies_data['overview'].fillna(''))
plot_similarity_matrix = cosine_similarity(tfidf_matrix)

# Fetch movie poster
def fetch_poster(movie_title):
    api_key = "0772b406c9680c6e12fe7bb717a80bd5"
    url = f"https://api.themoviedb.org/3/search/movie?api_key={api_key}&query={movie_title}"
    response = requests.get(url)
    data = response.json()
    if data['results']:
        poster_path = data['results'][0].get('poster_path')
        if poster_path:
            return f"https://image.tmdb.org/t/p/w500/{poster_path}"
    return "https://via.placeholder.com/300x450?text=No+Poster"

# Recommend function
def recommend(movie_title):
    movie_title = movie_title.lower()
    if movie_title not in movies_data['title'].str.lower().values:
        return [], []

    movie_index = movies_data[movies_data['title'].str.lower() == movie_title].index[0]
    plot_scores = plot_similarity_matrix[movie_index]

    # Genre similarity using Jaccard index
    movie_genres = set(movies_data.iloc[movie_index]['genre_list'])
    genre_scores = []
    for genres in movies_data['genre_list']:
        other_genres = set(genres)
        intersection = movie_genres.intersection(other_genres)
        union = movie_genres.union(other_genres)
        score = len(intersection) / len(union) if union else 0
        genre_scores.append(score)

    # Final similarity: weighted sum
    final_scores = []
    for i in range(len(movies_data)):
        if i != movie_index:
            score = 0.7 * plot_scores[i] + 0.3 * genre_scores[i]
            final_scores.append((i, score))

    sorted_scores = sorted(final_scores, key=lambda x: x[1], reverse=True)[:10]
    recommended_titles = [movies_data.iloc[i]['title'] for i, _ in sorted_scores]
    recommended_posters = [fetch_poster(title) for title in recommended_titles]

    return recommended_titles, recommended_posters

# GUI setup
root = tk.Tk()
root.title("🎬 Movie Recommendation System")
root.geometry("1000x800")

# Title
title_label = tk.Label(root, text="The Rec Room", font=("Helvetica", 18, "bold"))
title_label.pack(pady=10)

# Create tabs
tab_control = ttk.Notebook(root)
tab1 = tk.Frame(tab_control)  # Recommendations
tab2 = tk.Frame(tab_control)  # Browse by Genre
tab_control.add(tab1, text='📽️ Recommendations')
tab_control.add(tab2, text='🎭 Browse by Genre')
tab_control.pack(expand=1, fill="both")

# === TAB 1: Recommendations ===
selected_movie = tk.StringVar()
movie_dropdown = ttk.Combobox(tab1, textvariable=selected_movie, values=list(movies_data['title'].values), width=50)
movie_dropdown.pack(pady=10)

recommend_canvas = tk.Canvas(tab1, height=350)
recommend_scrollbar = ttk.Scrollbar(tab1, orient="vertical", command=recommend_canvas.yview)
recommend_canvas.configure(yscrollcommand=recommend_scrollbar.set)
recommend_scrollbar.pack(side="right", fill="y")
recommend_canvas.pack(side="left", fill="both", expand=True)

recommend_frame = tk.Frame(recommend_canvas)
recommend_canvas.create_window((0, 0), window=recommend_frame, anchor="nw")
recommend_frame.bind("<Configure>", lambda e: recommend_canvas.configure(scrollregion=recommend_canvas.bbox("all")))
recommend_canvas.bind_all("<MouseWheel>", lambda e: recommend_canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))

def show_recommendations():
    for widget in recommend_frame.winfo_children():
        widget.destroy()
    loading_label = tk.Label(recommend_frame, text="Loading...", font=("Helvetica", 14, "bold"))
    loading_label.pack(pady=20)
    root.update()
    names, posters = recommend(selected_movie.get())
    loading_label.destroy()
    for i in range(len(names)):
        try:
            response = requests.get(posters[i])
            img_data = response.content
            img = Image.open(io.BytesIO(img_data)).resize((150, 220))
            poster_img = ImageTk.PhotoImage(img)
            label = tk.Label(recommend_frame, text=names[i], image=poster_img, compound="top", wraplength=150)
            label.image = poster_img
            label.grid(row=i // 5, column=i % 5, padx=15, pady=15)
        except Exception as e:
            print(f"Error loading poster for {names[i]}: {e}")

tk.Button(tab1, text="Recommend", command=show_recommendations, bg="#ff4d4d", fg="white").pack(pady=10)

# === TAB 2: Browse by Genre ===
top_genres = ['Action', 'Comedy', 'Drama', 'Romance', 'Science Fiction']
selected_genre = tk.StringVar()
genre_dropdown = ttk.Combobox(tab2, textvariable=selected_genre, values=top_genres, width=30)
genre_dropdown.pack(pady=10)

genre_frame = tk.Frame(tab2)
genre_frame.pack(pady=10)

def show_genre_movies():
    for widget in genre_frame.winfo_children():
        widget.destroy()

    genre = selected_genre.get()
    genre_movies = movies_data[movies_data['genre_list'].apply(lambda x: genre in x)].head(10)

    for i, row in enumerate(genre_movies.itertuples()):
        try:
            poster_url = fetch_poster(row.title)
            response = requests.get(poster_url)
            img_data = response.content
            img = Image.open(io.BytesIO(img_data)).resize((100, 150))
            poster_img = ImageTk.PhotoImage(img)
            label = tk.Label(genre_frame, text=row.title, image=poster_img, compound="top")
            label.image = poster_img
            label.grid(row=i // 5, column=i % 5, padx=5, pady=5)
        except:
            continue

tk.Button(tab2, text="Show Genre Movies", command=show_genre_movies, bg="#4CAF50", fg="white").pack(pady=10)

root.mainloop()
